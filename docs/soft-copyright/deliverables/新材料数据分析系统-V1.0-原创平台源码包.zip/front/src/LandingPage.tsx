import { type CSSProperties, useEffect, useState } from 'react';
import { Boxes, ClipboardCheck, Database, Download, Network, type LucideIcon } from 'lucide-react';
import { SOFTWARE_SHORT_NAME, SOFTWARE_VERSION } from './appMeta';
import loginIcon from './images/登录.svg';
import registerIcon from './images/注册.svg';
import copyIcon from './images/复制.svg';
import brandLogo from './images/Logo.svg';
import workbenchIcon from './images/工作台.svg';
import capabilityOmeletIcon from './images/capability-omelet.svg';
import capabilityCaMatrixIcon from './images/capability-ca-matrix.svg';
import capabilityOmeletSvIcon from './images/capability-omelet-sv.svg';
import capabilityPythonIcon from './images/capability-python.svg';
import capabilityFastapiIcon from './images/capability-fastapi.svg';
import capabilityNumpyIcon from './images/capability-numpy.svg';
import capabilityScipyIcon from './images/capability-scipy.svg';
import capabilityEchartsIcon from './images/capability-echarts.svg';

const DEFAULT_FRONTEND_ORIGIN = 'http://127.0.0.1:5173';
const ACCESS_PATHS = [
  '/login',
  '/register',
];

function getFrontendOrigin() {
  return typeof window === 'undefined' ? DEFAULT_FRONTEND_ORIGIN : window.location.origin;
}

async function copyUrl(value: string) {
  if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(value);
    return;
  }

  if (typeof document === 'undefined') {
    throw new Error('当前环境不支持复制地址');
  }

  const input = document.createElement('textarea');
  input.value = value;
  input.setAttribute('readonly', '');
  input.style.position = 'fixed';
  input.style.opacity = '0';
  document.body.appendChild(input);
  input.select();
  const copied = document.execCommand('copy');
  document.body.removeChild(input);

  if (!copied) {
    throw new Error('复制地址失败');
  }
}

// 首页能力条使用本地 SVG，避免首屏依赖第三方图标服务。
const CAPABILITY_MARKS = [
  { label: '数据导入', short: 'DATA', display: 'OMELET', icon: capabilityOmeletIcon, tone: 'blue' },
  { label: 'CA 矩阵', short: 'CA', display: 'CA Matrix', icon: capabilityCaMatrixIcon, tone: 'indigo' },
  { label: 'OMELET-SV', short: 'SV', display: 'OMELET-SV', icon: capabilityOmeletSvIcon, tone: 'cyan' },
  { label: '多核学习', short: 'MKL', display: 'Python', icon: capabilityPythonIcon, tone: 'violet' },
  { label: 'Python 算法实现', short: 'PY', display: 'FastAPI', icon: capabilityFastapiIcon, tone: 'green' },
  { label: 'FastAPI 服务编排', short: 'API', display: 'NumPy', icon: capabilityNumpyIcon, tone: 'orange' },
  { label: '可视化看板', short: 'CHART', display: 'SciPy', icon: capabilityScipyIcon, tone: 'blue' },
  { label: '结果导出', short: 'EXPORT', display: 'ECharts', icon: capabilityEchartsIcon, tone: 'slate' },
] as const;

const DETAIL_CARDS = [
  {
    title: '数据管理',
    description: '导入基础聚类结果、查看基础聚类统计、随机选择样本并创建聚类任务。',
  },
  {
    title: '协关联矩阵分析',
    description: '构建 CA 矩阵，并通过热力图查看样本间协关联结构。',
  },
  {
    title: '多核相似性学习',
    description: '选择核函数、设置参数、构建基础核矩阵并执行集成聚类算法。',
  },
  {
    title: '性能评估',
    description: '计算 ACC、NMI、ARI、F1-score，并支持多次运行统计。',
  },
  {
    title: '可视化展示',
    description: '展示 CA 矩阵热力图、核权重分布、拓扑亲和矩阵、聚类散点图和收敛曲线。',
  },
  {
    title: '结果导出',
    description: '导出聚类标签、指标表格、图像结果、运行日志，并生成聚类分析报告。',
  },
];

type WorkflowStage = {
  order: string;
  title: string;
  description: string;
  Icon: LucideIcon;
  positionX: string;
  nodeY: string;
  placement: 'upper' | 'lower';
};

const ANALYSIS_WORKFLOW_STAGES: readonly WorkflowStage[] = [
  {
    order: '01',
    title: '选择基础聚类结果',
    description: '导入并确认基础结果',
    Icon: Database,
    positionX: '9%',
    nodeY: '82px',
    placement: 'upper',
  },
  {
    order: '02',
    title: 'GBE 编码与 CA 构建',
    description: '生成协关联矩阵',
    Icon: Boxes,
    positionX: '29.5%',
    nodeY: '154px',
    placement: 'lower',
  },
  {
    order: '03',
    title: '多核相似性学习',
    description: '优化融合权重',
    Icon: Network,
    positionX: '50%',
    nodeY: '82px',
    placement: 'upper',
  },
  {
    order: '04',
    title: '谱聚类与指标评估',
    description: '形成标签并计算核心指标',
    Icon: ClipboardCheck,
    positionX: '70.5%',
    nodeY: '154px',
    placement: 'lower',
  },
  {
    order: '05',
    title: '结果落盘',
    description: '保存标签、图表与运行产物',
    Icon: Download,
    positionX: '91%',
    nodeY: '82px',
    placement: 'upper',
  },
];

type WorkflowStageStyle = CSSProperties & {
  '--workflow-stage-x': string;
  '--workflow-node-y': string;
};

function TopBar() {
  return (
    <header className="landing-topbar">
      <div className="landing-topbar-inner">
        <div className="landing-brand">
          <span className="brand-logo" aria-hidden="true">
            <img className="brand-logo-image" src={brandLogo} width={32} height={32} alt="" aria-hidden="true" />
          </span>
          <span className="landing-brand-copy">
            <strong>{SOFTWARE_SHORT_NAME}</strong>
          </span>
        </div>
        <span className="landing-version-pill" aria-label={`当前版本 ${SOFTWARE_VERSION}`}>
          {SOFTWARE_VERSION}
        </span>
      </div>
    </header>
  );
}

function BaseUrlRow() {
  const [index, setIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const frontendOrigin = getFrontendOrigin();
  const activePath = ACCESS_PATHS[index];
  const fullAccessUrl = `${frontendOrigin}${activePath}`;

  useEffect(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia === 'undefined') return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (mq.matches) return;
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % ACCESS_PATHS.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const handleCopy = async () => {
    try {
      await copyUrl(fullAccessUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="base-url-row" role="group" aria-label="登录或注册页面地址">
      <span className="base-url-address" title={frontendOrigin}>{frontendOrigin}</span>
      <span key={activePath} className="base-url-endpoint" title={activePath}>
        {activePath}
      </span>
      <button
        type="button"
        className="base-url-copy"
        aria-label={copied ? '已复制地址' : '复制地址'}
        onClick={handleCopy}
      >
        <img className="base-url-copy-icon" src={copyIcon} width={14} height={14} alt="" aria-hidden="true" />
      </button>
      <span className="sr-only" aria-live="polite">
        {copied ? '地址已复制' : ''}
      </span>
    </div>
  );
}

function Hero({
  onLogin,
  onRegister,
}: {
  onLogin: () => void;
  onRegister: () => void;
}) {
  return (
    <section className="landing-hero" aria-label="新材料数据分析平台介绍">
      <div className="blur-ball blur-ball-indigo" aria-hidden="true" />
      <div className="blur-ball blur-ball-teal" aria-hidden="true" />
      <div className="landing-hero-inner">
        <div className="landing-hero-copy">
          <h1>
            新材料
            <br />
            <span className="shine-text">数据分析统一平台</span>
          </h1>
          <p className="hero-subtitle">
            登录或注册页面地址：
          </p>
        </div>

        <BaseUrlRow />

        <div className="hero-buttons" aria-label="首页账号操作">
          <button type="button" className="btn btn-primary hero-btn" onClick={onLogin}>
            <img className="hero-btn-icon" src={loginIcon} width={16} height={16} alt="" aria-hidden="true" />
            登录
          </button>
          <button type="button" className="btn btn-secondary hero-btn" onClick={onRegister}>
            <img className="hero-btn-icon" src={registerIcon} width={16} height={16} alt="" aria-hidden="true" />
            注册
          </button>
        </div>

        <CapabilityStrip />
      </div>
    </section>
  );
}

function CapabilityStrip() {
  return (
    <section className="landing-capability-strip" id="datasets" aria-labelledby="capability-title">
      <h2 id="capability-title">覆盖完整的分析链路</h2>
      <div className="capability-mark-grid" aria-label="分析链路能力">
        {CAPABILITY_MARKS.map((item) => {
          return (
            <span
              key={item.label}
              className={`capability-mark capability-mark-${item.tone}`}
              aria-label={item.label}
              title={item.label}
            >
              <img className="capability-mark-icon" src={item.icon} alt="" aria-hidden="true" />
              <strong>{item.short}</strong>
              <span className="capability-mark-label">{item.display}</span>
            </span>
          );
        })}
      </div>
    </section>
  );
}

function DetailSection() {
  return (
    <section className="landing-section" aria-labelledby="detail-title">
      <div className="landing-section-inner">
        <div className="landing-section-header">
          <span className="landing-section-kicker">平台能力</span>
          <h2 id="detail-title">从数据管理到分析报告的完整流程</h2>
          <p>
            围绕基础聚类结果、CA 矩阵、多核相似性学习、性能评估、可视化展示与结果导出，形成面向新材料数据分析的闭环工作流。
          </p>
        </div>

        <div className="capability-grid">
          {DETAIL_CARDS.map((item) => (
            <article key={item.title} className="capability-card">
              <span className="capability-icon" aria-hidden="true" />
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function WorkflowTimelineSection() {
  return (
    <section className="landing-workflow-section" aria-labelledby="workflow-timeline-title">
      <div className="landing-section-inner">
        <div className="landing-workflow-card">
          <header className="landing-workflow-heading">
            <div>
              <span className="landing-workflow-kicker">执行流程</span>
              <h2 id="workflow-timeline-title">分析执行脉络</h2>
            </div>
            <p>从基础聚类结果到可交付分析产物</p>
          </header>

          <ol className="landing-workflow-timeline" aria-label="五阶段分析执行流程">
            <svg
              className="workflow-route"
              viewBox="0 0 1000 240"
              preserveAspectRatio="none"
              aria-hidden="true"
              focusable="false"
            >
              <defs>
                <linearGradient id="workflow-route-gradient" x1="0%" y1="50%" x2="100%" y2="50%">
                  <stop offset="0%" stopColor="#60a5fa" />
                  <stop offset="48%" stopColor="#2dd4bf" />
                  <stop offset="100%" stopColor="#60a5fa" />
                </linearGradient>
              </defs>
              <path
                className="workflow-route-path"
                d="M 90 82 C 190 82, 190 154, 295 154 S 400 82, 500 82 S 605 154, 705 154 S 810 82, 910 82"
              />
            </svg>
            {ANALYSIS_WORKFLOW_STAGES.map(({ order, title, description, Icon, positionX, nodeY, placement }) => {
              const stageStyle: WorkflowStageStyle = {
                '--workflow-stage-x': positionX,
                '--workflow-node-y': nodeY,
              };

              return (
                <li key={title} className={`workflow-stage is-${placement}`} style={stageStyle}>
                  <div className="workflow-stage-copy">
                    <span className="workflow-stage-order">{order}</span>
                    <h3>{title}</h3>
                    <p>{description}</p>
                  </div>
                  <span className="workflow-stage-node" aria-hidden="true">
                    <Icon size={17} strokeWidth={2.1} />
                  </span>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </section>
  );
}

function AboutSection({
  onEnterWorkbench,
  isEnteringWorkbench,
}: {
  onEnterWorkbench: () => void | Promise<void>;
  isEnteringWorkbench: boolean;
}) {
  return (
    <section className="landing-section landing-section-compact" id="about" aria-labelledby="about-title">
      <div className="landing-section-inner landing-about-card">
        <div className="landing-about-copy">
          <span className="landing-section-kicker">系统概览</span>
          <h2 id="about-title">拓扑感知多核集成聚类分析系统</h2>
          <p>
            系统以新材料数据分析为场景，串联数据管理、协关联矩阵分析、多核相似性学习、性能评估、可视化展示与结果导出，支撑从基础聚类结果导入到聚类分析报告生成的完整流程。
          </p>
        </div>
        <button
          type="button"
          className="landing-link-button"
          disabled={isEnteringWorkbench}
          aria-busy={isEnteringWorkbench}
          onClick={() => void onEnterWorkbench()}
        >
          {isEnteringWorkbench ? '正在验证登录状态' : '前往分析工作台'}
          <img
            className="landing-link-button-icon"
            src={workbenchIcon}
            width={16}
            height={16}
            alt=""
            aria-hidden="true"
          />
        </button>
      </div>
    </section>
  );
}

export function LandingPage({
  onLogin,
  onRegister,
  onEnterWorkbench,
  isEnteringWorkbench = false,
}: {
  onLogin: () => void;
  onRegister: () => void;
  onEnterWorkbench: () => void | Promise<void>;
  isEnteringWorkbench?: boolean;
}) {
  // 首页隐藏视口滚动条（仅视觉），卸载时恢复其他页面的默认滚动条。
  useEffect(() => {
    document.body.classList.add('landing-scroll-hidden');
    return () => {
      document.body.classList.remove('landing-scroll-hidden');
    };
  }, []);

  return (
    <div className="landing-page">
      <TopBar />
      <main className="landing-main">
        <Hero onLogin={onLogin} onRegister={onRegister} />
        <DetailSection />
        <WorkflowTimelineSection />
        <AboutSection onEnterWorkbench={onEnterWorkbench} isEnteringWorkbench={isEnteringWorkbench} />
      </main>
    </div>
  );
}

export default LandingPage;
